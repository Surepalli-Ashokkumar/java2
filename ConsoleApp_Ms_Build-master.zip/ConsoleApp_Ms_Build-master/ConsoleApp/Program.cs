﻿using System;

namespace ConsoleApp
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hello World! from Thetips4you");
        }
    }
}
